<?php
namespace App\Controllers;
use App\Models\UserModel;
use App\Models\StateModel;
use App\Models\AdminModel;
use App\Models\TransactionModel;
use App\Models\CityModel;
use App\Models\ActiveUserModel;
use App\Models\CountryModel;
use App\Models\PinModel;
use App\Libraries\Paginationnew;
use App\Libraries\SiteVariables;
use App\Libraries\EmailSms;

class TransactionController extends BaseController {

    protected $session;
    protected $isAdminLoggedIn;


    public function __construct() {
        $this->session = session();
        $siteVariables = new SiteVariables();
        $this->isAdminLoggedIn = $this->session->get('isAdminLoggedIn');
    }

    public function index() {
        $session = session();
          $searchArray = array();
        if (!$this->isAdminLoggedIn) {
            return redirect()->to(site_url('admin'));
        }

        if ($session->get('user_id')) {

            
            $username = $session->get('username');

             if($username)
        {
           
            $searchArray['username'] = $username;

        }

        }
 
        $TransactionModel = new TransactionModel();
        $paginationnew = new Paginationnew();
        $txtsearch = $this->request->getGet('txtsearch');
        $Payment_status = $this->request->getGet('Payment_status');
        $pay_by = $this->request->getGet('pay_by');
      
        if($txtsearch)
        {
            $searchArray['txtsearch'] = $txtsearch;
        }
        if($Payment_status)
        {
            $searchArray['Payment_status'] = $Payment_status;
        }

          if($pay_by)
        {
            $searchArray['pay_by'] = $pay_by;
        }
        $siteVariables = new SiteVariables();
      

        $page = $this->request->getGet('page');
        $page = $page ? $page : 1;
        $Limit = PER_PAGE_RECORD;
        $totalRecord = $TransactionModel->getData($searchArray, '', '', '1');
        $startLimit = ($page - 1) * $Limit;		
		$data['reverse'] = $totalRecord-($page -1) * $Limit;
        $data['startLimit'] = $startLimit;
        $pagination = $paginationnew->getPaginate($totalRecord, $page, $Limit);
        $data['txtsearch'] = $txtsearch;
        $data['startLimit'] = $startLimit;
        $data['pagination'] = $pagination;
     
           $data["searchArray"] = $searchArray;
        
        
       

        $data['list'] = $TransactionModel->getData($searchArray, $startLimit, $Limit);

        // echo"<pre>";
        //   print_r($data['list']);exit;

        $this->template->render('admintemplate', 'contents', 'admin/transaction/transactionlist', $data);
    }

  
    public function preview() {
        $session = session();

        $isAdminLoggedIn = $session->get('isAdminLoggedIn');

        if (!$isAdminLoggedIn) {
            return redirect()->to(site_url('admin'));
        }

        $id = $this->request->getGet("id");
      $searchArray["tr_id"] = $id;

        $TransactionModel = new TransactionModel();
        $data['preview'] = $TransactionModel->getData($searchArray); // return count value
// echo"<pre>";
//        print_r($data['preview']);exit;

        if (!$data['preview']) {
            $this->session->setFlashdata('errmessage', 'Does not exist!');
            return redirect()->to(site_url('viewtransaction'));
        }

        $this->template->render('admintemplate', 'contents', 'admin/transaction/preview', $data);
    }






}

?>

