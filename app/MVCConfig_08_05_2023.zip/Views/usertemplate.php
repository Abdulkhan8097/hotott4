<?php echo view('user/header');  ?> 

<?php echo $contents ?>
<?php echo view('user/footer'); ?>
 </div>
</div>
	<!-- JAVASCRIPT -->
	<script src="<?php echo base_url('admin/libs/jquery/jquery.min.js'); ?>"></script>
	<script src="<?php echo base_url('admin/libs/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
	<script src="<?php echo base_url('admin/libs/metismenu/metisMenu.min.js'); ?>"></script>
	<script src="<?php echo base_url('admin/libs/simplebar/simplebar.min.js'); ?>"></script>
	<script src="<?php echo base_url('admin/libs/node-waves/waves.min.js'); ?>"></script>

	<script src="<?php echo base_url('admin/libs/parsleyjs/parsley.min.js'); ?>"></script>
	<script src="<?php echo base_url('admin/js/pages/form-validation.init.js'); ?>"></script>

	<!-- Peity chart-->
	<script src="<?php echo base_url('admin/libs/peity/jquery.peity.min.js'); ?>"></script>

	<!-- Plugin Js-->
	<script src="<?php echo base_url('admin/libs/chartist/chartist.min.js'); ?>"></script>
	<script src="<?php echo base_url('admin/libs/chartist-plugin-tooltips/chartist-plugin-tooltip.min.js'); ?>"></script>

	<script src="<?php echo base_url('admin/js/pages/dashboard.init.js'); ?>"></script>

	<script src="<?php echo base_url('admin/js/app.js'); ?>"></script>

	<script src="<?php echo base_url('admin/js/custom.js'); ?>"></script>

	</body>
</html>