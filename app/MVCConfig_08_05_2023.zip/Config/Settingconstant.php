<?php
define('SITE_NAME', 'HOTOTT');
define('SITE_LOGO', 'admin_logo.png');
define('ADMIN_THEME', 'sb-admin_blue');
define('LEFTPANEL', '1');
define('UPDATE_THUMB_WIDTH', '559');
define('UPDATE_THUMB_HEIGHT', '315');
define('PER_PAGE_RECORD', '20');
define('ADMIN_SITE_LOGO', 'admin_logo.png');
define('TIME_ZONE_FOR_DB', 'America/New_York');
define('SMTP_EMAIL', 'atulyadav.genie@gmail.com');
define('SMTP_EMAIL_PASSWORD', 'genie@123');
define('SMTP_EMAIL_HOST', 'localhost');
define('SMTP_EMAIL_PORT', '25');
define('FACEBOOK_URL', 'facebook.com');
define('TWITTER_URL', 'twitter.com');
define('GOOGLE_URL', 'google.com');
define('PER_OMR_POINT', 10);
?>