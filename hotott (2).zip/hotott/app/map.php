<script type="text/javascript" id="debugbar_loader" data-time="1675771824" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1674220476" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1674218055" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1673853403" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1672301138" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1672293720" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1672055815" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671709084" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671709005" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671629580" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671615456" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671609862" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671605791" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<script type="text/javascript" id="debugbar_loader" data-time="1671203116" src="http://165.22.219.135/kokanngo/index.php?debugbar"></script><script type="text/javascript" id="debugbar_dynamic_script"></script><style type="text/css" id="debugbar_dynamic_style"></style>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script><style>
@media only screen and (max-width: 700px){
.modal-content {
width: 100%;
}
}
.elementor-564 .elementor-element.elementor-element-16eade2 img {
margin-left: 30%;
}
.elementor-854 .elementor-element.elementor-element-1e5bb927 .donate-btn {
text-decoration: none;
}
.elementor-854 .elementor-element.elementor-element-1e5bb927 .main-menu .main-menu__list > li > a, .stricky-header .main-menu__list > li > a {
text-decoration: none;
}
.main-menu .main-menu__list li ul li a, .stricky-header .main-menu__list li ul li a {
text-decoration: none;
}
.list-unstyled {
line-height: 33px;
}
.footer-widget__links-list li a {
text-decoration: none;
}
.elementor-564 .elementor-element.elementor-element-983d375 .footer-widget__title {
font-family: "Montserrat", Sans-serif;
font-weight: 700;
}
.footer-widget__title {
font-size: 20px;
color: var(--pifoxen-white, #ffffff);
line-height: 30px;
margin-bottom: 20px;
}
.footer-widget__links-list li a {
font-family: "Montserrat", Sans-serif;
font-size: 15px;
color: #a8a8a8;
font-weight: 500;
-webkit-transition: all 500ms ease;
transition: all 500ms ease;
}
.elementor-854 .elementor-element.elementor-element-1e5bb927 .main-menu .main-menu__list > li > a, .stricky-header .main-menu__list > li > a {
font-size: 15px;
font-weight: 400;
line-height: 20px;
letter-spacing: -0.6px;
word-spacing: 0px;
font-family: "Montserrat", Sans-serif;
}
.main-menu .main-menu__list li ul li a, .stricky-header .main-menu__list li ul li a {
font-size: 16px;
line-height: 30px;
color: var(--pifoxen-black, #343434);
letter-spacing: 0;
font-weight: 400;
display: -webkit-box;
display: -ms-flexbox;
display: flex;
padding-left: 20px;
padding-right: 20px;
padding-top: 10px;
padding-bottom: 10px;
-webkit-transition: 500ms;
transition: 500ms;
font-family: "Montserrat", Sans-serif;
}
.site-footer__bottom-text {
font-size: 15px;
color: #a8a8a8;
font-weight: 500;
margin: 0px;
font-family: "Montserrat", Sans-serif;
}
.elementor-564 .elementor-element.elementor-element-965c812 .elementor-button {
text-decoration: none;
}
.elementor-564 .elementor-element.elementor-element-a6eb625 > .elementor-widget-container {
margin-bottom: -17px;
}
.site-footer__bottom-inner {
margin-left: 63px;
}
.site-footer__social a {
text-decoration: none;
}
.site-footer__social {
margin-right: -2%;
}
@media (min-width: 1200px){
.para{
text-align: left!important;
margin: 1px -10px 0px 20px!important;
font-size: 15px!important;
line-height: 23px!important;
}
.imgwid{
width: 100%!important;
}
.modal-content {
width: 100%!important;
margin-left: 0px!important;
}
.modal-header .close {
margin-top: 0px!important;
font-size: 32px!important;
}
}
@media (min-width: 768px){
.modal-content {
width: 177%;
margin-left: -187px;
}
.imgwid{
width: 119%;
}
.para{
text-align: left;
margin: 1px -10px 0px 20px;
font-size: 27px;
line-height: 40px;
}
.modal-header .close {
margin-top: -2px;
font-size: 73px;
}
}
</style>
Modal
<div class="modal fade" id="myModal" role="dialog" style="top:120px;">
<div class="modal-dialog">
<!-- Modal content-->
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal">×</button>
</div>
<div class="modal-body">
<img src="../public/website/images/upiqrcode.jpg" class="imgwid" />
</div>
</div>
</div>
</div>
<div data-elementor-type="wp-page" data-elementor-id="10598" class="elementor elementor-10598">
<section class="elementor-section elementor-top-section elementor-element elementor-element-a6af25d elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="a6af25d" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-cea56be" data-id="cea56be" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-74a5142 elementor-widget elementor-widget-heading" data-id="74a5142" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<style>/*! elementor - v3.7.8 - 02-10-2022 */
.elementor-heading-title{padding:0;margin:0;line-height:1}.elementor-widget-heading .elementor-heading-title[class*=elementor-size-]>a{color:inherit;font-size:inherit;line-height:inherit}.elementor-widget-heading .elementor-heading-title.elementor-size-small{font-size:15px}.elementor-widget-heading .elementor-heading-title.elementor-size-medium{font-size:19px}.elementor-widget-heading .elementor-heading-title.elementor-size-large{font-size:29px}.elementor-widget-heading .elementor-heading-title.elementor-size-xl{font-size:39px}.elementor-widget-heading .elementor-heading-title.elementor-size-xxl{font-size:59px}
</style>
<h2 class="elementor-heading-title elementor-size-default">Online Mode</h2>
</div>
</div>
</div>
</div>
</div>
</section>
<div data-elementor-type="wp-page" data-elementor-id="9009" class="elementor elementor-9009">
<section class="elementor-section elementor-top-section elementor-element elementor-element-b508c3d elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="b508c3d" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 bank elementor-top-column elementor-element elementor-element-ad84824" data-id="ad84824" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f2baad7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="f2baad7" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5f92a20 " data-id="5f92a20" data-element_type="column" data-settings="{" animation="" :="" fadeinleft="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-87f49b6 elementor-widget elementor-widget-text-editor" data-id="87f49b6" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container para">
<h3 style="font-weight: bold;">HDFC BANK DETAILS</h3>
<br />
Account Name: <b>Kokan Kala Va Shikshan Vikas Sanstha</b>
<hr />
Account No: <b>50100223511512</b>
<hr />
IFSC Code: <b>HDFC0002869</b>
<hr />
Branch: <b>Station Road, Dadar East, Mumbai-400014</b>
<hr />
Bank Name: <b>HDFC Bank</b>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
<div class="elementor-column elementor-col-50 bank elementor-top-column elementor-element elementor-element-ad84824" data-id="ad84824" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f2baad7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="f2baad7" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5f92a20 " data-id="5f92a20" data-element_type="column" data-settings="{" animation="" :="" fadeinleft="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-87f49b6 elementor-widget elementor-widget-text-editor" data-id="87f49b6" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container para">
<h3 style="font-weight: bold;">MAHARASHTRA BANK DETAILS</h3>
<br />
Account Name: <b> Kokan Kala Va Shikshan Vikas Sanstha</b>
<br />
Account No: <b> 60129595245</b>
<hr />
IFSC Code: <b>MAHB0000068</b>
<hr />
Branch: <b>Banda, Sawantwadi, Maharashtra, India</b>
<hr />
Bank Name: <b>Bank of Maharashtra</b>									</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 bank elementor-top-column elementor-element elementor-element-ad84824" data-id="ad84824" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f2baad7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="f2baad7" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5f92a20 " data-id="5f92a20" data-element_type="column" data-settings="{" animation="" :="" fadeinleft="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-87f49b6 elementor-widget elementor-widget-text-editor" data-id="87f49b6" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container para">
<h3 style="font-weight: bold;">HDFC BANK DETAILS</h3>
<br />
Account Name: <b>Kokan Kala Va Shikshan Vikas Sanstha</b>
<hr />
Account No: <b>50100223511512</b>
<hr />
IFSC Code: <b>HDFC0002869</b>
<hr />
Branch: <b>Station Road, Dadar East, Mumbai-400014</b>
<hr />
Bank Name: <b>HDFC Bank</b>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
<div class="elementor-column elementor-col-50 bank elementor-top-column elementor-element elementor-element-ad84824" data-id="ad84824" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f2baad7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="f2baad7" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5f92a20 " data-id="5f92a20" data-element_type="column" data-settings="{" animation="" :="" fadeinleft="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-87f49b6 elementor-widget elementor-widget-text-editor" data-id="87f49b6" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container para">
<h3 style="font-weight: bold;">MAHARASHTRA BANK DETAILS</h3>
<br />
Account Name: <b> Kokan Kala Va Shikshan Vikas Sanstha</b>
<br />
Account No: <b> 60129595245</b>
<hr />
IFSC Code: <b>MAHB0000068</b>
<hr />
Branch: <b>Banda, Sawantwadi, Maharashtra, India</b>
<hr />
Bank Name: <b>Bank of Maharashtra</b>									</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 bank elementor-top-column elementor-element elementor-element-ad84824" data-id="ad84824" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f2baad7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="f2baad7" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5f92a20 " data-id="5f92a20" data-element_type="column" data-settings="{" animation="" :="" fadeinleft="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-87f49b6 elementor-widget elementor-widget-text-editor" data-id="87f49b6" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container para">
<h3 style="font-weight: bold;">BY CHEQUE</h3>
<br />
Draft Your Cheque in The Names <br />
<b> Kokan Kala Va Shikshan Vikas Sanstha</b> <br />
And Send it to 102, Madhavwadi, Near (I) Building, Opp. Saibaba Temple, M.M.G.S. Road, Dadar(East), Mumbai-400 014, Maharashtra, India.						</div>
<br />
</div>
</div>
</div>
</div>
</section>
</div>
</div>
<div class="elementor-column elementor-col-50 bank elementor-top-column elementor-element elementor-element-ad84824" data-id="ad84824" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-f2baad7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="f2baad7" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5f92a20 " data-id="5f92a20" data-element_type="column" data-settings="{" animation="" :="" fadeinleft="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-87f49b6 elementor-widget elementor-widget-text-editor" data-id="87f49b6" data-element_type="widget" data-widget_type="text-editor.default" style="margin-top: -30px;">
<div class="elementor-widget-container" style="text-align: left;">
<h3 style="font-weight: bold;">QR Code</h3>
<a href="javascript:;" data-toggle="modal" data-target="#myModal">
<img src="../public/website/images/upiqrcode.jpg" style="max-width: 48%;
margin-left: 25%;" />
</a>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
</div>
<section class="elementor-section elementor-top-section elementor-element elementor-element-68f8f8d elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="68f8f8d" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7648967" data-id="7648967" data-element_type="column">
<div class="elementor-widget-wrap elementor-element-populated">
<section class="elementor-section elementor-inner-section elementor-element elementor-element-7c57700 elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="7c57700" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3cfd294 " data-id="3cfd294" data-element_type="column" data-settings="{" animation="" :="" fadeindown="">
<div class="elementor-widget-wrap elementor-element-populated">
</div>
</div>
<div class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-0cbee01 " data-id="0cbee01" data-element_type="column" data-settings="{" animation="" :="" fadeindown="">
<div class="elementor-widget-wrap elementor-element-populated">
</div>
</div>
</div>
</section>
</div>
</div>
</div>
</section>
<section class="elementor-section elementor-top-section elementor-element elementor-element-3a4edfa elementor-section-boxed elementor-section-height-default elementor-section-height-default wpr-particle-no wpr-jarallax-no wpr-parallax-no wpr-sticky-section-no" data-id="3a4edfa" data-element_type="section">
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-eb25fc7 " data-id="eb25fc7" data-element_type="column" data-settings="{" animation="" :="" fadeindown="">
<div class="elementor-widget-wrap elementor-element-populated">
<div class="elementor-element elementor-element-80627e3 elementor-widget elementor-widget-heading" data-id="80627e3" data-element_type="widget" data-widget_type="heading.default">
<div class="elementor-widget-container">
<h3 class="elementor-heading-title elementor-size-default" style="font-weight: bold;">Important Information :</h3>
</div>
</div>
<div class="elementor-element elementor-element-ef3717a elementor-widget elementor-widget-text-editor" data-id="ef3717a" data-element_type="widget" data-widget_type="text-editor.default">
<div class="elementor-widget-container" style="margin-left: -2%;line-height: 39px;">
<ul class="para" style="line-height: 42px!important;">
	<li>Please avoid making a donation of less than Rs.500/- as the processing costs make it unviable for us.</li>
	<li>All funds/donations raised by KOKAN NGO may be pooled together and allocated to other welfare projects depending on the need on the ground.</li>
	<li>All donations are eligible for 50% tax benefit under section 80g of the Bombay public trust act.</li>
	<li>After completing the payment process, you will receive the receipt of your Donation on your registered email.</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
