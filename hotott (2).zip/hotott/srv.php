<?php

    //$ipaddress = '';
     $ipaddress = '';
     $ipaddress = $_SERVER['REMOTE_ADDR'];

    echo 'ipaddress->'.$ipaddress;exit;
   
?>