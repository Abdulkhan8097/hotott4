<?php

namespace Mpdf\Tag;

class Ol extends BlockTag
{


}
